package org.netbeans.modules.javascript.loaders;

import org.openide.loaders.DataNode;
import org.openide.nodes.Children;

public class JSDataNode extends DataNode {
    
    private static final String IMAGE_ICON_BASE = "org/netbeans/modules/javascript/jsObject.png";
    
    public JSDataNode(JSDataObject obj) {
        super(obj, Children.LEAF);
        setIconBaseWithExtension(IMAGE_ICON_BASE);
    }
    
//    /** Creates a property sheet. */
//    protected Sheet createSheet() {
//        Sheet s = super.createSheet();
//        Sheet.Set ss = s.get(Sheet.PROPERTIES);
//        if (ss == null) {
//            ss = Sheet.createPropertiesSet();
//            s.put(ss);
//        }
//        // TODO add some relevant properties: ss.put(...)
//        return s;
//    }
    
}
