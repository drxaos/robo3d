function print1(x) { x+="."; print(x);}
function print(x)  {
  document.write(stacktrace())
  document.write("&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Parameter = "+x+"<BR>")
}

function funcname(f) {
 var s = f.toString().match(/function (\w*)/)[1];
 if ((s == null) || (s.length==0)) return "anonymous";
 return s;
}
function stacktrace() {
 var s = "";
 for (var a = arguments.caller; a !=null; a = a.caller) {
   s += "->"+funcname(a.callee) + "\n";
   if (a.caller == a) {s+="*"; break;}
 }
 return s;
}
print1("TEST")
print1("THIS")